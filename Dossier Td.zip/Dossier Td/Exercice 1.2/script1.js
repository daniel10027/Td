document.write("<P>Du texte écrit en javascript.</P>");
alert("Hello world ! en javascript");