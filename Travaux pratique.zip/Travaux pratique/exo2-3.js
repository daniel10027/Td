var window_handle; 
function open_window(){ 
window_handle = window.open("fenetre.html");
} 
function close_window(){ 
window_handle.close(); 
} 
window.setInterval("open_window();", 1, "JavaScript"); 
 window.setInterval(" window_handle.close();", 3000, "JavaScript");