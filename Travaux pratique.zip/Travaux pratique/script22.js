function displayDivInfo(text){
 	if(text){ 
 	 		is_ie =
 	 		(navigator.userAgent.toLowerCase().indexOf("msie") != -1) && (navigator.userAgent.toLowerCase().indexOf("opera") == -1); 		 	
 	 		 		var divInfo = document.createElement('div'); 		divInfo.style.position = 'absolute'; 		document.onmousemove = function(e){ 
 	 		 					x = (!is_ie ? e.pageX-window.pageXOffset : event.x+document.body.scrollLeft); 
y = (!is_ie ? e.pageY-window.pageYOffset : event.y+document.body.scrollTop); 	
divInfo.style.left = x+15+'px'; 		
divInfo.style.top = y+15+'px'; 	
} 	
divInfo.id = 'divInfo'; 	
divInfo.innerHTML = text; 		document.body.appendChild(divInfo); 
} 	
else{ 		
document.onmousemove = ''; 		document.body.removeChild(document.getElementById('divInfo')); 
 
 } 
}