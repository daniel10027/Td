var annee = prompt("Entrez une annee");
  
   if ((annee%4==0) && ((annee%100!=0) || (annee%400==0))) {
   	alert( annee + " est une année bissextile");
   	}
    else {
    	alert(annee + " n’est pas une année bissextile "); 
    } 
    
alert("Fin du programme !");
